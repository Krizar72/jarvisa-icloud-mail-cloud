import { connect } from 'cloudflare:sockets';
import { ImapFlow } from 'imapflow';
import PostalMime from 'postal-mime';
import { address, folder, uid, draft, searchArgs } from './validation.js';

// A fresh TLS session for every call; credentials and message bodies are never logged.
export async function withImap(env, fn) {
  if (!env.ICLOUD_PASSWORD || !env.ICLOUD_EMAIL) throw new Error('Account cloud non configurato.');
  const client = new ImapFlow({host:'imap.mail.me.com',port:993,secure:true,
    auth:{user:env.ICLOUD_USERNAME || env.ICLOUD_EMAIL,pass:env.ICLOUD_PASSWORD},
    logger:false,disableAutoIdle:true,disableCompression:true,
    connectionTimeout:15000,greetingTimeout:15000,socketTimeout:20000});
  client.on('error',()=>{});
  try { await client.connect(); return await fn(client); }
  finally { try { await client.logout(); } catch { client.close(); } }
}
const addresses = values => (values || []).map(v => v.name ? `${v.name} <${v.address}>` : v.address).join(', ');
function envelope(m) {
  return {uid:String(m.uid),from:addresses(m.envelope?.from),to:addresses(m.envelope?.to),subject:m.envelope?.subject || '',date:m.envelope?.date?.toISOString() || '',size:m.size};
}
export async function callMail(name,args,env) {
  if(name==='get_status') return {configured:!!(env.ICLOUD_EMAIL && env.ICLOUD_PASSWORD),hosting:'cloudflare-workers-free',mac_required:false,connection_tested:false};
  if(name==='prepare_draft') return draft(args,env.ICLOUD_EMAIL);
  if(name==='send_email') {
    if(env.SEND_ENABLED!=='true') throw new Error('Invio cloud non ancora abilitato.');
    return sendMail(draft(args,env.ICLOUD_EMAIL),env);
  }
  return withImap(env,async client=>{
    if(name==='list_folders') return {folders:(await client.list()).map(x=>({path:x.path,name:x.name}))};
    const mailbox = folder(args.folder);
    const lock = await client.getMailboxLock(mailbox,{readOnly:true});
    try {
      if(name==='search_messages') {
        const q=searchArgs(args); const query={all:true};
        if(q.text) query.text=q.text;
        if(q.unseen) query.seen=false;
        const uids=await client.search(query,{uid:true});
        const chosen=uids.slice(-q.limit).reverse();const messages=[];
        for(const id of chosen){const m=await client.fetchOne(id,{envelope:true,size:true},{uid:true});if(m)messages.push(envelope(m));}
        return {folder:mailbox,total:uids.length,messages};
      }
      if(name==='read_message') {
        const id=uid(args.uid);
        const meta=await client.fetchOne(id,{size:true,envelope:true},{uid:true});
        if(!meta) throw new Error('Messaggio non trovato.');
        if(meta.size>5000000) throw new Error('Messaggio oltre il limite di 5 MB.');
        // ImapFlow source uses BODY.PEEK[]; EXAMINE also prevents marking messages read.
        const raw=await client.fetchOne(id,{source:true},{uid:true});
        if(!raw?.source) throw new Error('Messaggio non trovato.');
        const parsed=await PostalMime.parse(raw.source);
        return {...envelope(meta),body:(parsed.text || parsed.html || '').slice(0,50000),body_type:parsed.text?'text/plain':'text/html',attachments:(parsed.attachments||[]).map(a=>({filename:a.filename,type:a.mimeType})),hosting:'cloudflare-workers-free'};
      }
      throw new Error('Strumento non disponibile.');
    } finally { lock.release(); }
  });
}

// Line reader with explicit lock release before Cloudflare STARTTLS upgrades.
class Lines {
  constructor(socket){this.socket=socket;this.reader=socket.readable.getReader();this.writer=socket.writable.getWriter();this.buffer='';this.decoder=new TextDecoder();this.total=0;}
  async line(){
    while(!this.buffer.includes('\r\n')) {
      const {value,done}=await this.reader.read();if(done)throw new Error('Connessione chiusa.');
      this.total+=value.byteLength;if(this.total>65536)throw new Error('Risposta server troppo grande.');
      this.buffer+=this.decoder.decode(value,{stream:true});
    }
    const i=this.buffer.indexOf('\r\n');const value=this.buffer.slice(0,i);this.buffer=this.buffer.slice(i+2);return value;
  }
  async send(value){await this.writer.write(new TextEncoder().encode(value+'\r\n'));}
  async reply(expected){let line;do{line=await this.line();if(!/^\d{3}[ -]/.test(line))throw new Error('Risposta SMTP non valida.');}while(line[3]==='-');if(Number(line.slice(0,3))!==expected)throw new Error('Risposta SMTP inattesa.');return line;}
  release(){this.reader.releaseLock();this.writer.releaseLock();}
}
async function smtpSession(action) {
  let socket=connect({hostname:'smtp.mail.me.com',port:587},{secureTransport:'starttls'});let lines;
  const timeout=setTimeout(()=>{socket.close().catch(()=>{});},20000);
  try {
    await socket.opened;lines=new Lines(socket);await lines.reply(220);
    await lines.send('EHLO jarvisa.invalid');await lines.reply(250);
    await lines.send('STARTTLS');await lines.reply(220);
    if(lines.buffer)throw new Error('Dati SMTP inattesi prima di TLS.');
    lines.release();lines=undefined;socket=socket.startTls();await socket.opened;lines=new Lines(socket);
    await lines.send('EHLO jarvisa.invalid');await lines.reply(250);
    return await action(lines);
  } finally {clearTimeout(timeout);try{lines?.release();}catch{}try{await socket.close();}catch{}}
}
export async function networkProbe() {
  const imap=async()=>{let s=connect({hostname:'imap.mail.me.com',port:993},{secureTransport:'on'});const timer=setTimeout(()=>s.close().catch(()=>{}),15000);let l;try{await s.opened;l=new Lines(s);const greeting=await l.line();if(!greeting.startsWith('* OK'))throw new Error('IMAP greeting');return {tls:true,reachable:true};}finally{clearTimeout(timer);try{l?.release();await s.close();}catch{}}};
  const smtp=async()=>smtpSession(async l=>{await l.send('QUIT');await l.reply(221);return {starttls:true,reachable:true,no_message_sent:true};});
  const result=await Promise.allSettled([imap(),smtp()]);
  return Object.fromEntries(['imap_993','smtp_587'].map((k,i)=>[k,result[i].status==='fulfilled'?result[i].value:{reachable:false,error:'Connessione o TLS non riusciti.'}]));
}
export async function sendMail(message,env) {
  return smtpSession(async l=>{
    await l.send('AUTH PLAIN '+btoa('\0'+env.ICLOUD_EMAIL+'\0'+env.ICLOUD_PASSWORD));await l.reply(235);
    await l.send(`MAIL FROM:<${address(message.from)}>`);await l.reply(250);
    for(const recipient of message.to){await l.send(`RCPT TO:<${address(recipient)}>`);await l.reply(250);}
    await l.send('DATA');await l.reply(354);
    const encodedSubject=Buffer.from(message.subject,'utf8').toString('base64');
    const body=Buffer.from(message.body,'utf8').toString('base64').match(/.{1,76}/g)?.join('\r\n') || '';
    const raw=[`From: ${message.from}`,`To: ${message.to.join(', ')}`,`Subject: =?UTF-8?B?${encodedSubject}?=`,`Date: ${new Date().toUTCString()}`,`Message-ID: <${crypto.randomUUID()}@jarvisa.invalid>`,'MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64','',body].join('\r\n');
    // Never retry after DATA: an uncertain response may already mean delivery.
    await l.send(raw+'\r\n.');await l.reply(250);
    try{await l.send('QUIT');await l.reply(221);}catch{}
    return {accepted_by_smtp:message.to,refused:[],delivery_confirmed:false};
  });
}
