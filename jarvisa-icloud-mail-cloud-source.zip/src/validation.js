export function address(value) {
  if (typeof value !== 'string' || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value)) throw new Error('Indirizzo email non valido.');
  return value;
}
export function folder(value = 'INBOX') {
  if (typeof value !== 'string' || value.length > 512 || /[\r\n\0]/.test(value)) throw new Error('Cartella non valida.');
  return value;
}
export function uid(value) {
  if (typeof value !== 'string' || !/^[1-9][0-9]*$/.test(value) || !Number.isSafeInteger(Number(value))) throw new Error('UID non valido.');
  return Number(value);
}
export function draft(args, from) {
  if (!Array.isArray(args.to) || args.to.length < 1 || args.to.length > 20) throw new Error('Inserisci da 1 a 20 destinatari.');
  const to = args.to.map(address);
  if (typeof args.subject !== 'string' || /[\r\n]/.test(args.subject) || args.subject.length > 1000) throw new Error('Oggetto non valido.');
  if (typeof args.body !== 'string' || args.body.length > 100000) throw new Error('Corpo non valido.');
  return { sent: false, from: address(from), to, subject: args.subject, body: args.body };
}
export function searchArgs(args) {
  const limit = args.limit ?? 10;
  if (!Number.isInteger(limit) || limit < 1 || limit > 20) throw new Error('Limite non valido.');
  if (args.text !== undefined && (typeof args.text !== 'string' || args.text.length > 1000 || /[\r\n\0]/.test(args.text))) throw new Error('Ricerca non valida.');
  return { limit, text: args.text ?? '', folder: folder(args.folder), unseen: args.unread_only === true };
}
export async function equalSecret(a, b) {
  if (!a || !b) return false;
  const hash = async s => new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)));
  const [x,y] = await Promise.all([hash(a),hash(b)]);
  let diff = 0;
  for (let i=0;i<x.length;i++) diff |= x[i]^y[i];
  return diff === 0;
}
// A consent POST must come from this service's own origin.
export function validConsentOrigin(request) {
  return request.headers.get('Origin') === new URL(request.url).origin;
}
