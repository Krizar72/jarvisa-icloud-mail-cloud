import { OAuthProvider, AuthorizationError } from '@cloudflare/workers-oauth-provider';
import tools from './tools.json';
import { callMail, networkProbe } from './mail.js';
import { equalSecret, validConsentOrigin } from './validation.js';

const json = (value,status=200,headers={})=>Response.json(value,{status,headers:{'Cache-Control':'no-store',...headers}});
const escape = v=>String(v).replace(/[&<>"']/g,c=>`&#${c.charCodeAt(0)};`);
const activeTools = env=>tools.filter(t=>t.name!=='send_email'||env.SEND_ENABLED==='true');
const rpcError = (id,code,message,status=200)=>json({jsonrpc:'2.0',id:id??null,error:{code,message}},status);

async function mcp(request,env,ctx) {
  const scopes=ctx.auth?.scope || [];
  if(ctx.props?.userId!=='owner' || !scopes.includes('mail:read')) return json({error:'forbidden'},403);
  if(request.method!=='POST') return new Response(null,{status:405,headers:{Allow:'POST'}});
  if(!request.headers.get('Content-Type')?.includes('application/json')) return json({error:'unsupported_media_type'},415);
  if(Number(request.headers.get('Content-Length')||0)>150000) return json({error:'request_too_large'},413);
  const raw=await request.text();if(raw.length>150000)return json({error:'request_too_large'},413);
  let rpc;try{rpc=JSON.parse(raw);}catch{return rpcError(null,-32700,'Parse error',400);}
  if(!rpc || Array.isArray(rpc) || rpc.jsonrpc!=='2.0' || typeof rpc.method!=='string')return rpcError(rpc?.id,-32600,'Invalid Request',400);
  if(!('id' in rpc))return new Response(null,{status:202});
  let result;
  switch(rpc.method) {
    case 'initialize': result={protocolVersion:['2025-11-25','2025-06-18','2025-03-26','2024-11-05'].includes(rpc.params?.protocolVersion)?rpc.params.protocolVersion:'2025-03-26',capabilities:{tools:{}},serverInfo:{name:'jarvisa-icloud-mail-cloud',version:'0.1.0'}};break;
    case 'ping': result={};break;
    case 'tools/list': result={tools:activeTools(env)};break;
    case 'tools/call': {
      const name=rpc.params?.name;
      if(!activeTools(env).some(t=>t.name===name))return rpcError(rpc.id,-32602,'Unknown tool');
      if(name==='send_email'&&!scopes.includes('mail:send'))return rpcError(rpc.id,-32602,'Autorizzazione invio mancante.');
      const args=rpc.params?.arguments ?? {};
      if(!args || typeof args!=='object'||Array.isArray(args))return rpcError(rpc.id,-32602,'Invalid arguments');
      const schema=activeTools(env).find(t=>t.name===name).inputSchema;
      if(Object.keys(args).some(k=>!(k in schema.properties))||(schema.required||[]).some(k=>!(k in args)))return rpcError(rpc.id,-32602,'Invalid arguments');
      try {const value=await callMail(name,args,env);result={content:[{type:'text',text:JSON.stringify(value)}],isError:false};}
      catch {result={content:[{type:'text',text:name==='send_email'?'Invio non confermato. Verifica la posta inviata prima di riprovare.':'Operazione non riuscita. Verifica configurazione, parametri e connessione iCloud.'}],isError:true};}
      break;
    }
    default:return rpcError(rpc.id,-32601,'Method not found');
  }
  return json({jsonrpc:'2.0',id:rpc.id,result});
}

async function authorize(request,env) {
  if(!env.OWNER_PASSWORD || env.OWNER_PASSWORD.length<24)return new Response('Accesso proprietario non ancora configurato.',{status:503});
  const oauth=env.OAUTH_PROVIDER;
  if(request.method==='GET') {
    const auth=await oauth.parseAuthRequest(request);
    const details=await oauth.describeConsent(auth);
    const consent=await oauth.beginConsent(auth);
    const canSend=env.SEND_ENABLED==='true';
    const page=`<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Jarvisa iCloud Mail</title><style>body{font:17px system-ui;max-width:550px;margin:40px auto;padding:20px}input,button{font:inherit;padding:12px;max-width:100%}label{display:block;margin:15px 0}button{cursor:pointer}</style><h1>Jarvisa iCloud Mail</h1><p>Richiesta di collegamento da <strong>${escape(details.clientName)}</strong>.</p><p>Destinazione autorizzata: <strong>${escape(details.redirectHost)}</strong>.</p>${details.clientDomain?`<p>Dominio del client: ${escape(details.clientDomain)}</p>`:''}<p>Consenti l’accesso alla tua posta soltanto se hai avviato questo collegamento da ChatGPT.</p><form method="post" action="/authorize"><input type="hidden" name="handle" value="${escape(consent.handle)}"><input type="hidden" name="scope" value="mail:read"><input type="hidden" name="scope" value="offline_access"><p>Lettura cartelle, ricerca, lettura messaggi e preparazione bozze.</p>${canSend?'<label><input type="checkbox" name="scope" value="mail:send"> Consenti anche l’invio email su mia richiesta</label>':''}<label>Password privata Jarvisa (non la password Apple)<br><input name="password" type="password" autocomplete="current-password" required minlength="24"></label><button name="decision" value="approve">Collega ChatGPT</button> <button name="decision" value="deny" formnovalidate>Annulla</button></form></html>`;
    consent.headers.set('Content-Type','text/html; charset=utf-8');consent.headers.set('Cache-Control','no-store');consent.headers.set('Referrer-Policy','same-origin');
    consent.headers.set('Content-Security-Policy',`default-src 'none'; style-src 'unsafe-inline'; form-action 'self' ${new URL(auth.redirectUri).origin}; frame-ancestors 'none'; base-uri 'none'`);
    return new Response(page,{headers:consent.headers});
  }
  if(request.method!=='POST')return new Response(null,{status:405,headers:{Allow:'GET, POST'}});
  if(!validConsentOrigin(request))return new Response('Origine non valida.',{status:403});
  if(Number(request.headers.get('Content-Length')||0)>10000)return new Response(null,{status:413});
  const form=await request.formData();const handle=String(form.get('handle')||'');
  if(form.get('decision')!=='approve') {const denied=await oauth.denyConsent(request,handle);return new Response(null,{status:302,headers:denied.headers});}
  if(!await equalSecret(String(form.get('password')||''),env.OWNER_PASSWORD))return new Response('Password non valida. Riavvia il collegamento da ChatGPT.',{status:401,headers:{'Cache-Control':'no-store'}});
  const allowed=new Set(['mail:read','offline_access',...(env.SEND_ENABLED==='true'?['mail:send']:[])]);
  const scope=form.getAll('scope').map(String).filter(s=>allowed.has(s));
  if(!scope.includes('mail:read'))return new Response('Ambito non valido.',{status:400});
  const approved=await oauth.approveConsent(request,handle,{scope});
  const complete=await oauth.completeAuthorization({request:approved.request,userId:'owner',metadata:{},scope:approved.request.scope,props:{userId:'owner'}});
  approved.headers.set('Location',complete.redirectTo);return new Response(null,{status:302,headers:approved.headers});
}

const publicHandler={async fetch(request,env) {
  const path=new URL(request.url).pathname;
  if(path==='/health'&&request.method==='GET')return json({service:'jarvisa-icloud-mail-cloud',host:'cloudflare',mac_required:false,configured:!!(env.OAUTH_KV&&env.OWNER_PASSWORD&&env.ICLOUD_PASSWORD),version:'0.1.0'});
  if(path==='/network-probe'&&request.method==='POST') {
    if(!await equalSecret(request.headers.get('Authorization'),env.PROBE_TOKEN?'Bearer '+env.PROBE_TOKEN:''))return json({error:'unauthorized'},401);
    return json(await networkProbe());
  }
  if(path==='/authorize') {
    try{return await authorize(request,env);}catch(error){
      if(error instanceof AuthorizationError&&error.redirectTo)return Response.redirect(error.redirectTo,302);return new Response('Autorizzazione non valida o scaduta. Riavvia da ChatGPT.',{status:400});}
  }
  return new Response('Jarvisa iCloud Mail cloud. Endpoint privato: /mcp',{status:path==='/'?200:404,headers:{'Cache-Control':'no-store'}});
}};

export default {async fetch(request,env,ctx) {
  // Until the account has its free KV namespace, no mail or authorization route runs.
  if(!env.OAUTH_KV) {
    if(['/','/health','/network-probe'].includes(new URL(request.url).pathname))return publicHandler.fetch(request,env,ctx);
    return json({error:'setup_required'},503);
  }
  const origin=new URL(request.url).origin;
  const provider=new OAuthProvider({apiRoute:'/mcp',apiHandler:{fetch:mcp},defaultHandler:publicHandler,
    authorizeEndpoint:'/authorize',tokenEndpoint:'/oauth/token',clientRegistrationEndpoint:'/oauth/register',
    scopesSupported:['mail:read','mail:send','offline_access'],requiredScopes:['mail:read'],
    resourceMetadata:{resource:origin+'/mcp',authorization_servers:[origin]},
    clientIdMetadataDocumentEnabled:true,accessTokenTTL:3600,refreshTokenTTL:2592000});
  return provider.fetch(request,env,ctx);
}};

export { mcp, authorize };
