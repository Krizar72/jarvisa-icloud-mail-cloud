// Isolated workerd integration test. Uses synthetic credentials and never reads mail.
import { spawn } from 'node:child_process';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join,resolve } from 'node:path';
import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';

const dir=await mkdtemp(join(tmpdir(),'jarvisa-cloud-test-'));
const base='http://127.0.0.1:8788';
const redirect='https://chatgpt.com/test-callback';
const password='synthetic-test-password-not-a-real-secret';
const config={name:'jarvisa-icloud-mail-test',main:resolve('src/worker.js'),compatibility_date:'2026-10-17',compatibility_flags:['nodejs_compat','global_fetch_strictly_public'],kv_namespaces:[{binding:'OAUTH_KV',id:'00000000000000000000000000000000'}],vars:{OWNER_PASSWORD:password,SEND_ENABLED:'false'}};
await writeFile(join(dir,'wrangler.json'),JSON.stringify(config));
let log='';
const child=spawn(process.execPath,['node_modules/wrangler/bin/wrangler.js','dev','--local','--port','8788','--config',join(dir,'wrangler.json'),'--persist-to',join(dir,'state')],{cwd:process.cwd(),detached:true,env:{...process.env,WRANGLER_SEND_METRICS:'false',BROWSER:'none'},stdio:['ignore','pipe','pipe']});
child.stdout.on('data',b=>{log+=b});child.stderr.on('data',b=>{log+=b});
try {
  let ready=false;
  for(let i=0;i<80;i++){try{const r=await fetch(base+'/health');if(r.ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,250));}
  assert(ready,'workerd startup failed: '+log.slice(-1500));
  const unauth=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/list'})});
  assert.equal(unauth.status,401);assert(unauth.headers.get('WWW-Authenticate')?.includes('resource_metadata'));
  const probe=await fetch(base+'/network-probe',{method:'POST'});assert.equal(probe.status,401);
  const registration=await fetch(base+'/oauth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_name:'Jarvisa isolated test',redirect_uris:[redirect],grant_types:['authorization_code','refresh_token'],response_types:['code'],token_endpoint_auth_method:'none'})});
  assert.equal(registration.status,201);const client=await registration.json();
  const verifier=randomBytes(32).toString('base64url');const challenge=createHash('sha256').update(verifier).digest('base64url');
  const url=new URL(base+'/authorize');for(const [k,v] of Object.entries({response_type:'code',client_id:client.client_id,redirect_uri:redirect,scope:'mail:read offline_access',code_challenge:challenge,code_challenge_method:'S256',state:'test-state',resource:base+'/mcp'}))url.searchParams.set(k,v);
  const consent=await fetch(url);const html=await consent.text();assert.equal(consent.status,200);
  assert(html.includes('Jarvisa isolated test'));assert(!html.includes('value="mail:send"'));
  assert(consent.headers.get('Content-Security-Policy').includes("form-action 'self' https://chatgpt.com;"));
  assert.equal(consent.headers.get('Referrer-Policy'),'same-origin');
  const handle=html.match(/name="handle" value="([^"]+)"/)[1];
  const cookie=consent.headers.getSetCookie().map(s=>s.split(';')[0]).join('; ');
  const approved=await fetch(base+'/authorize',{method:'POST',redirect:'manual',headers:{Origin:base,Cookie:cookie},body:new URLSearchParams([['handle',handle],['password',password],['decision','approve'],['scope','mail:read'],['scope','offline_access']])});
  assert.equal(approved.status,302,await approved.text());const callback=new URL(approved.headers.get('Location'));
  assert.equal(callback.searchParams.get('state'),'test-state');const code=callback.searchParams.get('code');assert(code);
  const replay=await fetch(base+'/authorize',{method:'POST',redirect:'manual',headers:{Origin:base,Cookie:cookie},body:new URLSearchParams([['handle',handle],['password',password],['decision','approve'],['scope','mail:read']])});assert.equal(replay.status,400);
  const exchange=await fetch(base+'/oauth/token',{method:'POST',body:new URLSearchParams({grant_type:'authorization_code',client_id:client.client_id,code,code_verifier:verifier,redirect_uri:redirect,resource:base+'/mcp'})});
  assert.equal(exchange.status,200);const token=await exchange.json();assert(token.access_token);
  const rpc=async(method,params)=>{const r=await fetch(base+'/mcp',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token.access_token},body:JSON.stringify({jsonrpc:'2.0',id:2,method,params})});assert.equal(r.status,200);return r.json();};
  const init=await rpc('initialize',{protocolVersion:'2025-03-26'});assert.equal(init.result.serverInfo.name,'jarvisa-icloud-mail-cloud');
  const listed=await rpc('tools/list');assert.equal(listed.result.tools.length,5);assert(!listed.result.tools.some(t=>t.name==='send_email'));
  const status=await rpc('tools/call',{name:'get_status'});assert.equal(status.result.isError,false);assert(JSON.parse(status.result.content[0].text).mac_required===false);
  const send=await rpc('tools/call',{name:'send_email',arguments:{to:['nobody@example.com'],subject:'no send',body:'not sent'}});assert(send.error);
  const malformed=await rpc('tools/call',{name:'read_message',arguments:{uid:'1:*'}});assert.equal(malformed.result.isError,true);
  const forged=await rpc('tools/call',{name:'read_message',arguments:{uid:'1',extra:'forbidden'}});assert(forged.error);
  console.log('PASS workerd: unauthenticated access denied, probe protected, DCR, PKCE, consent, one-use handle, token exchange, MCP tools, no send, argument checks. No mail read.');
} catch(error){console.error(error.message);process.exitCode=1;}
finally {try{process.kill(-child.pid,'SIGTERM');}catch{}await new Promise(r=>setTimeout(r,500));await rm(dir,{recursive:true,force:true});}
