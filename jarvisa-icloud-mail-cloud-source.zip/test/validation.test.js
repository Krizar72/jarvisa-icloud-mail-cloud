import test from 'node:test';
import assert from 'node:assert/strict';
import { address, folder, uid, draft, searchArgs, equalSecret, validConsentOrigin } from '../src/validation.js';
test('refuses message/header/IMAP injection and ambiguous identifiers',()=>{
  for(const a of ['a@example.com\r\nBcc: x@example.com','<a@example.com>','a@example.com b@example.com'])assert.throws(()=>address(a));
  for(const id of ['0','1:*','1\r\nDELETE','9007199254740993'])assert.throws(()=>uid(id));
  assert.throws(()=>folder('INBOX\r\nEXPUNGE'));
  assert.throws(()=>draft({to:['a@example.com'],subject:'hello\r\nBcc: bad@example.com',body:'hello'},'owner@icloud.com'));
  assert.throws(()=>searchArgs({limit:true}));
  assert.throws(()=>searchArgs({limit:21}));
});
test('drafts retain Unicode and are explicitly unsent',()=>{
  const d=draft({to:['a@example.com'],subject:'È una prova',body:'Ciao 🙂'},'owner@icloud.com');
  assert.equal(d.sent,false);assert.equal(d.body,'Ciao 🙂');assert.equal(uid('123'),123);
});
test('missing secrets fail closed',async()=>{
  assert.equal(await equalSecret('',''),false);
  assert.equal(await equalSecret('same','same'),true);
  assert.equal(await equalSecret('same','different'),false);
});

test('consent accepts only an explicit matching origin',()=>{
  const url='https://mail.example/authorize';
  assert.equal(validConsentOrigin(new Request(url,{headers:{Origin:'https://mail.example'}})),true);
  for(const origin of ['null','https://attacker.example','https://mail.example.attacker.example'])
    assert.equal(validConsentOrigin(new Request(url,{headers:{Origin:origin,'Sec-Fetch-Site':'same-origin',Cookie:'present=yes'}})),false);
  assert.equal(validConsentOrigin(new Request(url)),false);
});
